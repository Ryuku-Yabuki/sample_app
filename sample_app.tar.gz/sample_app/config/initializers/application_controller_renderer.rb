# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '785848cf374cc738de76bcda542cc838eb05d97561edb2d2d9745f849a9cf909f11044af98c12f5e933f5185fa957cbf4ed21fac74703784e9a3d1f49ba1fb08'
